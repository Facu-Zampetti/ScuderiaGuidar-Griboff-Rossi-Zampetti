// public/home.js
// VERSIÓN DE DEPURACIÓN (DEBUG)

document.addEventListener('DOMContentLoaded', async () => {
    console.log("✅ [home.js] DOM cargado. Iniciando scripts...");
    loadHeroVehicle();
    loadCategories();
});

// --- 1. Lógica del Hero ---
async function loadHeroVehicle() {
    const heroImg = document.getElementById('hero-img');
    const heroBadge = document.getElementById('hero-badge-text');
    const heroPrice = document.getElementById('hero-price');

    if (!heroImg) {
        console.warn("⚠️ [Hero] No se encontró el elemento #hero-img");
        return;
    }

    try {
        const response = await fetch('../api/get_vehicles.php?sort=price_desc');
        const vehicles = await response.json();

        if (vehicles.length > 0) {
            const topCar = vehicles[0];
            let photoPath = resolvePath(topCar.Foto);
            console.log(`🚗 [Hero] Auto destacado: ${topCar.Marca} ${topCar.Modelo}`);

            heroImg.style.opacity = 0;
            setTimeout(() => {
                heroImg.src = photoPath;
                heroImg.alt = `${topCar.Marca} ${topCar.Modelo}`;
                if(heroBadge) heroBadge.textContent = `Disponible: ${topCar.Marca} ${topCar.Modelo}`;
                if(heroPrice) heroPrice.textContent = `$${topCar.Precio} / día`;
                heroImg.style.opacity = 1;
            }, 200);

            heroImg.parentElement.style.cursor = 'pointer';
            heroImg.parentElement.addEventListener('click', () => {
                window.location.href = `reservation_system.html?id=${topCar.ID}`;
            });
        }
    } catch (error) {
        console.error("❌ [Hero] Error:", error);
    }
}

// --- 2. Lógica de Categorías (CON LOGS EXTRA) ---
async function loadCategories() {
    console.log("🔄 [Categorías] Iniciando función loadCategories...");

    const grid = document.getElementById('categories-grid');
    if (!grid) {
        console.error("❌ [Categorías] ERROR CRÍTICO: No existe el elemento con id 'categories-grid' en el HTML.");
        return;
    }
    console.log("✅ [Categorías] Contenedor encontrado en el DOM.");

    try {
        console.log("📡 [Categorías] Solicitando datos a ../api/get_types.php ...");
        const res = await fetch('../api/get_types.php');
        
        console.log(`📡 [Categorías] Estado HTTP: ${res.status}`);
        if (!res.ok) {
            throw new Error(`Error HTTP: ${res.status}`);
        }

        const categories = await res.json();
        console.log("📦 [Categorías] Datos recibidos (JSON):", categories);

        grid.innerHTML = ''; // Limpiar loader

        if (!Array.isArray(categories) || categories.length === 0) {
            console.warn("⚠️ [Categorías] El array de categorías está vacío o no es un array.");
            grid.innerHTML = '<p class="text-center col-span-full">No hay categorías disponibles.</p>';
            return;
        }

        categories.forEach(cat => {
            console.log(`🔹 [Categorías] Procesando: ${cat.Nombre}`);
            
            const imageSrc = cat.FotoEjemplo 
                ? resolvePath(cat.FotoEjemplo) 
                : 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=400';

            const linkUrl = `vehicle_catalog.html?type=${cat.ID_Tipos}`;

            const card = document.createElement('div');
            card.className = "card-elevated group cursor-pointer hover:shadow-lg transition-all duration-300 h-full flex flex-col overflow-hidden bg-white rounded-lg";
            
            card.innerHTML = `
                <a href="${linkUrl}" class="flex flex-col h-full">
                    <div class="relative overflow-hidden h-56">
                        <img src="${imageSrc}" 
                             alt="${cat.Nombre}" 
                             class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                             loading="lazy"
                             onerror="this.src='https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=400';">
                        
                        <div class="absolute top-4 right-4 bg-primary/90 backdrop-blur-sm text-white px-3 py-1 rounded text-sm font-bold shadow-md border border-white/10">
                            Base $${cat.Precio}/día
                        </div>
                    </div>
                    
                    <div class="p-6 flex-1 flex flex-col">
                        <h3 class="text-xl font-bold text-primary mb-2">${cat.Nombre}</h3>
                        <p class="text-text-secondary mb-4 text-sm line-clamp-2">
                            ${cat.Descripcion || 'Vehículos premium'}
                        </p>
                        
                        <div class="mt-auto flex items-center justify-between border-t border-gray-100 pt-4">
                            <span class="text-xs font-medium text-text-secondary bg-gray-100 px-3 py-1 rounded-full">
                                ${cat.CantidadAutos} Disponibles
                            </span>
                            <span class="text-secondary font-semibold text-sm flex items-center group-hover:translate-x-1 transition-transform">
                                Ver Autos →
                            </span>
                        </div>
                    </div>
                </a>
            `;
            grid.appendChild(card);
        });
        
        console.log("✅ [Categorías] Renderizado finalizado.");

    } catch (err) {
        console.error("❌ [Categorías] Error fatal:", err);
        grid.innerHTML = `<p class="text-red-500 text-center col-span-full">Error: ${err.message}</p>`;
    }
}

// --- 3. Helper ---
function resolvePath(path) {
    if (!path) return '';
    if (path.startsWith('http') || path.startsWith('../')) {
        return path;
    }
    return `../img/${path}`;
}