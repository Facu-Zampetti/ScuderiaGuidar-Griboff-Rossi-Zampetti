document.addEventListener('DOMContentLoaded', async () => {

    // --- 1. REFERENCIAS A ELEMENTOS HTML ---
    // Columna Derecha (Selector y Tarjeta)
    const selectVehiculo = document.getElementById('vehicle-select');
    const cardVehiculo = document.getElementById('vehicle-card');
    const imgVehiculo = document.getElementById('vehicle-img');
    const nameVehiculo = document.getElementById('vehicle-name');
    const infoVehiculo = document.getElementById('vehicle-info');
    const patentVehiculo = document.getElementById('vehicle-patent');
    
    // Columna Izquierda (Formulario y Precios)
    const form = document.getElementById('reservation-form');
    const dateInicio = document.getElementById('pickup-date');
    const dateFin = document.getElementById('return-date');
    const summaryPrecioDia = document.getElementById('summary-price-day');
    const summaryDias = document.getElementById('summary-days');
    const summaryTotal = document.getElementById('summary-total');

    // Estado local
    let allVehicles = [];
    let selectedVehiclePrice = 0;

    // --- 2. VERIFICAR SESIÓN ---
    try {
        const res = await fetch('../api/session.php', { credentials: 'include' });
        const data = await res.json();
        if (!data.logged) {
            alert("Debes iniciar sesión para poder reservar.");
            window.location.href = 'login.html'; // Redirigir al login
            return;
        }
        console.log("Sesión iniciada como:", data.user.nombre);
    } catch (e) {
        alert("Error de conexión. No se pudo verificar la sesión.");
    }

    // --- 3. CARGAR VEHÍCULOS EN EL SELECT ---
    async function loadVehicles() {
        try {
            // get_vehicles.php ya nos da el precio porque hace JOIN con tipos
            const res = await fetch('../api/get_vehicles.php');
            allVehicles = await res.json();
            
            selectVehiculo.innerHTML = '<option value="">-- Elige tu vehículo --</option>'; // Opción default

            allVehicles.forEach(auto => {
                if (auto.Disponibilidad == 1) { // Solo mostrar disponibles
                    const option = document.createElement('option');
                    option.value = auto.ID;
                    // El texto que se muestra en el desplegable
                    option.textContent = `${auto.Marca} ${auto.Modelo} ($${auto.Precio}/día)`;
                    selectVehiculo.appendChild(option);
                }
            });

            // Comprobar si llegamos desde el catálogo (ej: ?id=3)
            const urlParams = new URLSearchParams(window.location.search);
            const autoId = urlParams.get('id');
            if (autoId) {
                selectVehiculo.value = autoId;
                updateVehicleInfo(autoId); // Disparar actualización si hay ID
            }

        } catch (e) {
            console.error("Error al cargar vehículos", e);
            selectVehiculo.innerHTML = '<option value="">Error al cargar flota</option>';
        }
    }

    // --- 4. ACTUALIZAR INFO CUANDO SE ELIGE UN AUTO ---
    function updateVehicleInfo(id) {
        const auto = allVehicles.find(v => v.ID == id);

        if (auto) {
            // Mostrar la tarjeta
            cardVehiculo.classList.remove('hidden');
            
            // Llenar tarjeta
            imgVehiculo.src = auto.Foto; // Asumiendo que la ruta en la BBDD es correcta (ej: ../img/auto.jpg)
            imgVehiculo.alt = `${auto.Marca} ${auto.Modelo}`;
            nameVehiculo.textContent = `${auto.Marca} ${auto.Modelo}`;
            infoVehiculo.textContent = `${auto.TipoNombre} • $${auto.Precio}/día`;
            patentVehiculo.textContent = `Patente: ${auto.Patente}`;

            // Actualizar resumen en la izquierda
            selectedVehiclePrice = parseFloat(auto.Precio);
            summaryPrecioDia.textContent = `$${auto.Precio}`;
            calculateTotal(); // Recalcular por si ya había fechas
        } else {
            // Ocultar tarjeta y resetear precios si se elige "Elige..."
            cardVehiculo.classList.add('hidden');
            selectedVehiclePrice = 0;
            summaryPrecioDia.textContent = "-";
            calculateTotal();
        }
    }

    // --- 5. CALCULAR TOTAL EN VIVO ---
    function calculateTotal() {
        const inicio = dateInicio.value;
        const fin = dateFin.value;

        if (inicio && fin && selectedVehiclePrice > 0) {
            const d1 = new Date(inicio);
            const d2 = new Date(fin);
            
            if (d2 < d1) {
                summaryDias.textContent = "Error";
                summaryTotal.textContent = "Error";
                return;
            }

            // Calcular días (incluyendo el día de inicio y fin)
            const diffTime = Math.abs(d2 - d1);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // +1 para incluir ambos días

            const total = diffDays * selectedVehiclePrice;

            summaryDias.textContent = `${diffDays} días`;
            summaryTotal.textContent = `$${total.toLocaleString('es-AR')}`; // Formato de moneda
        } else {
            summaryDias.textContent = "-";
            summaryTotal.textContent = "-";
        }
    }

    // --- 6. ENVIAR RESERVA (FORM SUBMIT) ---
    async function submitReservation(e) {
        e.preventDefault(); // Evitar envío normal

        // Validaciones
        if (!selectVehiculo.value) {
            alert("Por favor, selecciona un vehículo.");
            return;
        }
        if (!dateInicio.value || !dateFin.value) {
            alert("Por favor, selecciona las fechas.");
            return;
        }

        const payload = {
            id_auto: selectVehiculo.value,
            fecha_inicio: dateInicio.value,
            fecha_fin: dateFin.value
            // NO enviamos el ID de cliente, el servidor lo sabe
        };

        try {
            document.getElementById('submit-reservation').disabled = true;
            document.getElementById('submit-reservation').textContent = "Procesando...";

            const res = await fetch('../api/create_reservation.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include', // Importante para enviar la cookie de sesión
                body: JSON.stringify(payload)
            });

            const result = await res.json();

            if (result.success) {
                alert("¡Reserva confirmada con éxito!");
                window.location.href = 'homepage.html'; // O a una página de "Mis Reservas"
            } else {
                // Mostrar error del servidor (ej: "Fechas no disponibles")
                alert("Error: " + result.message);
                document.getElementById('submit-reservation').disabled = false;
                document.getElementById('submit-reservation').textContent = "Confirmar y Reservar";
            }
        } catch (err) {
            alert("Error de conexión al guardar la reserva.");
            document.getElementById('submit-reservation').disabled = false;
            document.getElementById('submit-reservation').textContent = "Confirmar y Reservar";
        }
    }

    // --- 7. ASIGNAR EVENTOS ---
    selectVehiculo.addEventListener('change', (e) => updateVehicleInfo(e.target.value));
    dateInicio.addEventListener('change', calculateTotal);
    dateFin.addEventListener('change', calculateTotal);
    form.addEventListener('submit', submitReservation);

    // --- 8. EJECUCIÓN INICIAL ---
    loadVehicles(); // Llenar el <select> al cargar
});