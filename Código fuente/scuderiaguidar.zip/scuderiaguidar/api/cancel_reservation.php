<?php
// api/cancel_reservation.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';
session_start();

// 1. Seguridad básica
if (!isset($_SESSION['cliente_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// 2. Leer datos
$input = json_decode(file_get_contents('php://input'), true);
$id_reserva = $input['id_reserva'] ?? 0;
$id_cliente = $_SESSION['cliente_id'];

if (!$id_reserva) {
    echo json_encode(['success' => false, 'message' => 'ID de reserva inválido']);
    exit;
}

// 3. Validar que la reserva pertenezca a ESTE cliente (Seguridad Crítica)
// No queremos que un cliente cancele la reserva de otro
$check = $conn->prepare("SELECT ID, ID_Estado FROM reservas WHERE ID = ? AND ID_Cliente = ?");
$check->bind_param('ii', $id_reserva, $id_cliente);
$check->execute();
$res = $check->get_result();
$data = $res->fetch_assoc();
$check->close();

if (!$data) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Reserva no encontrada o no te pertenece']);
    exit;
}

// Si ya está cancelada o finalizada, no hacemos nada
if ($data['ID_Estado'] == 5 || $data['ID_Estado'] == 4) {
    echo json_encode(['success' => false, 'message' => 'Esta reserva no se puede cancelar']);
    exit;
}

// 4. Actualizar estado a 5 (Cancelada)
$update = $conn->prepare("UPDATE reservas SET ID_Estado = 5 WHERE ID = ?");
$update->bind_param('i', $id_reserva);

if ($update->execute()) {
    echo json_encode(['success' => true, 'message' => 'Reserva cancelada correctamente']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error al cancelar']);
}

$update->close();
close_db();
?>