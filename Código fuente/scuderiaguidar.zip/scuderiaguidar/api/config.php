<?php
// ==========================================
// config.php
// Configuración centralizada de conexión MySQLi
// para el proyecto Scuderia Guidar (XAMPP)
// ==========================================

// Parámetros de conexión
$DB_HOST = '127.0.0.1'; // Usar IP evita ciertos problemas con sockets
$DB_USER = 'root';      // Usuario por defecto en XAMPP
$DB_PASS = '';          // Contraseña vacía (por defecto en XAMPP)
$DB_NAME = 'scuderiaguidar_flota'; // Nombre exacto de tu base de datos
$DB_PORT = 3306;        // Puerto por defecto (puedes cambiarlo si usas otro)

// Crear conexión
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);

// Comprobar errores de conexión
if ($conn->connect_error) {
    header('Content-Type: text/plain; charset=utf-8');
    die("❌ Error al conectar con la base de datos:\n" . $conn->connect_error);
}

// Asegurar codificación UTF-8 para acentos y caracteres especiales
if (!$conn->set_charset('utf8mb4')) {
    header('Content-Type: text/plain; charset=utf-8');
    die("❌ Error al establecer el conjunto de caracteres UTF-8:\n" . $conn->error);
}

// Función opcional para cerrar la conexión
function close_db() {
    global $conn;
    if ($conn instanceof mysqli) {
        $conn->close();
    }
}
?>
