<?php
// api/get_vehicles.php
// Versión corregida y blindada contra errores de sintaxis HTML

// 1. Evitar que errores de PHP (Warnings) rompan el JSON
error_reporting(E_ALL);
ini_set('display_errors', 0); 

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/config.php';

// Verificación rápida de conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión BD']);
    exit;
}

// Query base
$sql = "SELECT
            a.ID,
            a.Marca,
            a.Modelo,
            a.Patente,
            a.Disponibilidad,
            a.Foto,
            t.ID_Tipos,
            t.Nombre AS TipoNombre,
            t.Precio
        FROM Autos a
        LEFT JOIN Tipos t ON a.ID_Tipos = t.ID_Tipos";

$conds = [];
$params = [];
$types = ''; 

// --- LÓGICA DE FILTROS ---

// 1. Tipo (Múltiple)
if (isset($_GET['type']) && !empty($_GET['type'])) {
    $rawTypes = explode(',', $_GET['type']);
    $cleanIds = [];
    
    // Validar que sean números
    foreach($rawTypes as $val) {
        $id = intval($val);
        if ($id > 0) $cleanIds[] = $id;
    }

    if (count($cleanIds) > 0) {
        // Crear (?,?,?)
        $placeholders = implode(',', array_fill(0, count($cleanIds), '?'));
        $conds[] = "a.ID_Tipos IN ($placeholders)";
        
        // Agregar tipos para bind
        $types .= str_repeat('i', count($cleanIds));
        foreach ($cleanIds as $id) {
            $params[] = $id;
        }
    }
}

// 2. Disponibilidad
if (isset($_GET['available']) && ($_GET['available'] === '0' || $_GET['available'] === '1')) {
    $conds[] = "a.Disponibilidad = ?";
    $types .= 'i';
    $params[] = (int) $_GET['available'];
}

// 3. Precios
if (isset($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $conds[] = "t.Precio >= ?";
    $types .= 'd';
    $params[] = (float) $_GET['min_price'];
}

if (isset($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $conds[] = "t.Precio <= ?";
    $types .= 'd';
    $params[] = (float) $_GET['max_price'];
}

// 4. Unir condiciones
if (count($conds) > 0) {
    $sql .= ' WHERE ' . implode(' AND ', $conds);
}

// 5. Ordenamiento
$sort = $_GET['sort'] ?? 'alpha';
switch ($sort) {
    case 'price_asc':  $sql .= ' ORDER BY t.Precio ASC'; break;
    case 'price_desc': $sql .= ' ORDER BY t.Precio DESC'; break;
    case 'alpha':      
    default:           $sql .= ' ORDER BY a.Marca ASC, a.Modelo ASC'; break;
}

// Preparar
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Error SQL Prepare']);
    exit;
}

// Bind Dinámico (Solución compatible)
if (count($params) > 0) {
    $bind_names[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i]; // Pasar por referencia
    }
    call_user_func_array(array($stmt, 'bind_param'), $bind_names);
}

$stmt->execute();
$result = $stmt->get_result();

$vehicles = [];
while ($row = $result->fetch_assoc()) {
    $vehicles[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($vehicles, JSON_UNESCAPED_UNICODE);
?>