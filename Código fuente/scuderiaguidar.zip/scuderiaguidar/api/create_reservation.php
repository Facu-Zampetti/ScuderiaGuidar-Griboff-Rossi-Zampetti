<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php'; // Asegúrate de que esto cargue tu $conn

// --- 1. VALIDAR SESIÓN ---
session_start();
if (!isset($_SESSION['cliente_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión.']);
    exit;
}
$id_cliente = $_SESSION['cliente_id'];

// --- 2. LEER DATOS ---
$input = json_decode(file_get_contents('php://input'), true);
$id_auto    = (int)($input['id_auto'] ?? 0);
$fecha_ini  = $input['fecha_inicio'] ?? '';
$fecha_fin  = $input['fecha_fin'] ?? '';

// --- 3. VALIDACIONES BÁSICAS ---
if ($id_auto <= 0 || empty($fecha_ini) || empty($fecha_fin)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
    exit;
}
if ($fecha_fin < $fecha_ini) {
    echo json_encode(['success' => false, 'message' => 'Fechas inválidas.']);
    exit;
}

try {
    $conn->begin_transaction();

    // --- 4. VERIFICAR DISPONIBILIDAD (LÓGICA SENIOR SIMPLIFICADA) ---
    // Buscamos si existe ALGUNA reserva confirmada o pendiente que choque con nuestras fechas
    // La lógica es: Si una reserva existente termina DESPUÉS de que yo empiece 
    // Y empieza ANTES de que yo termine, entonces hay choque.
    $sql_check = "SELECT ID FROM reservas 
                  WHERE ID_Auto = ? 
                  AND ID_Estado IN (1, 2) 
                  AND (Fecha_Inicio <= ? AND Fecha_Fin >= ?)";

    $stmt_check = $conn->prepare($sql_check);
    // Nota el orden: ID, Nueva_Fin, Nueva_Inicio
    $stmt_check->bind_param('iss', $id_auto, $fecha_fin, $fecha_ini);
    $stmt_check->execute();
    $stmt_check->store_result(); // Necesario para usar num_rows después

    if ($stmt_check->num_rows > 0) {
        $stmt_check->close();
        throw new Exception("El vehículo no está disponible en esas fechas.");
    }
    $stmt_check->close();

    // --- 5. CALCULAR PRECIO ---
    $sql_price = "SELECT t.Precio FROM autos a 
                  JOIN tipos t ON a.ID_Tipos = t.ID_Tipos 
                  WHERE a.ID = ?";
    $stmt_price = $conn->prepare($sql_price);
    $stmt_price->bind_param('i', $id_auto);
    $stmt_price->execute();
    $res_price = $stmt_price->get_result();

    if ($res_price->num_rows === 0) {
        throw new Exception("Auto no encontrado.");
    }

    $precio_diario = (float)$res_price->fetch_assoc()['Precio'];
    $stmt_price->close();

    // Cálculo de días
    $d1 = new DateTime($fecha_ini);
    $d2 = new DateTime($fecha_fin);
    // diff devuelve la diferencia. Si es el mismo día, da 0, por eso sumamos 1
    $dias = $d1->diff($d2)->days + 1; 
    $precio_total = $dias * $precio_diario;

    // --- 6. INSERTAR ---
    // Importante: Asegúrate de haber corrido el ALTER TABLE para 'Precio_Total'
    $sql_insert = "INSERT INTO reservas 
                   (ID_Auto, ID_Cliente, ID_Estado, Numero, Fecha_Inicio, Fecha_Fin, Fecha_Operacion, Precio_Total) 
                   VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?)"; // CURDATE() usa la fecha del server SQL

    $id_estado = 1; // 1 = Pendiente
    $numero_reserva = rand(100000, 999999); // Un número aleatorio simple

    $stmt_insert = $conn->prepare($sql_insert);
    // Tipos: i (auto), i (cliente), i (estado), i (numero), s (ini), s (fin), d (precio)
    $stmt_insert->bind_param('iiiissd', $id_auto, $id_cliente, $id_estado, $numero_reserva, $fecha_ini, $fecha_fin, $precio_total);

    if (!$stmt_insert->execute()) {
        throw new Exception("Error SQL: " . $stmt_insert->error);
    }
    $stmt_insert->close();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Reserva creada exitosamente', 'total' => $precio_total]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(422); // Entidad no procesable (Error lógico)
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

// No cerramos $conn aquí si config.php lo necesita, pero es buena práctica si es el final del script
$conn->close();
?>