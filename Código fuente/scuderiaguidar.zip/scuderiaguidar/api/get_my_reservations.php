<?php
// api/get_my_reservations.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';
session_start();

// 1. Seguridad: ¿Está logueado?
if (!isset($_SESSION['cliente_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

$id_cliente = $_SESSION['cliente_id'];

// 2. Consulta SQL con JOINs
// Traemos info de la Reserva, del Auto y del Estado
$sql = "SELECT 
            r.ID as ReservaID,
            r.Fecha_Inicio,
            r.Fecha_Fin,
            r.Precio_Total,
            r.Numero as CodigoReserva,
            r.ID_Estado,
            e.Nombre as EstadoNombre,
            a.Marca,
            a.Modelo,
            a.Foto
        FROM reservas r
        JOIN autos a ON r.ID_Auto = a.ID
        JOIN estados e ON r.ID_Estado = e.ID
        WHERE r.ID_Cliente = ?
        ORDER BY r.Fecha_Inicio DESC"; // Las más recientes primero

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_cliente);
$stmt->execute();
$res = $stmt->get_result();

$reservas = [];
while ($row = $res->fetch_assoc()) {
    $reservas[] = $row;
}

$stmt->close();
close_db();

echo json_encode($reservas, JSON_UNESCAPED_UNICODE);
?>