<?php
// api/get_types.php
// IMPORTANTE: Este archivo debe estar limpio, sin espacios antes de <?php

header('Content-Type: application/json; charset=utf-8');
// Ajusta la ruta a config.php si es necesario. 
// __DIR__ apunta a la carpeta actual (api), por lo que '/config.php' busca en api/config.php. 
// Si tu config.php también está en 'api', esto está bien. 
// Si config.php está fuera de api (en la raiz), usa '/../config.php'.
require_once __DIR__ . '/config.php'; 

// Verificamos conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de BD: " . $conn->connect_error]);
    exit;
}

// SQL que incluye las fotos y cantidad
$sql = "SELECT 
            t.ID_Tipos, 
            t.Nombre, 
            t.Descripcion, 
            t.Precio,
            (SELECT Foto FROM autos a WHERE a.ID_Tipos = t.ID_Tipos AND a.Disponibilidad = 1 LIMIT 1) as FotoEjemplo,
            (SELECT COUNT(*) FROM autos a WHERE a.ID_Tipos = t.ID_Tipos) as CantidadAutos
        FROM Tipos t
        ORDER BY t.Nombre ASC";

$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(["error" => "Error en consulta SQL: " . $conn->error]);
    exit;
}

$types = [];
while ($row = $result->fetch_assoc()) {
    $types[] = $row;
}

// Importante: cerrar conexión
if ($conn instanceof mysqli) {
    $conn->close();
}

echo json_encode($types, JSON_UNESCAPED_UNICODE);
?>