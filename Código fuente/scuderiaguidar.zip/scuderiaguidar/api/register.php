<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';

// --- LEER JSON ---
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'JSON inválido.']);
    exit;
}

// --- FUNCION HELP ---
function fail($errors, $code = 400) {
    http_response_code($code);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// --- CAMPOS ---
$first      = trim($data['firstName'] ?? '');
$last       = trim($data['lastName'] ?? '');
$email      = trim($data['email'] ?? '');
$phone      = trim($data['phone'] ?? '');
$dni        = trim($data['dni'] ?? '');
$birth      = trim($data['dateOfBirth'] ?? '');
$password   = $data['password'] ?? '';
$hasLicense = (int)($data['hasLicense'] ?? 0);
$address    = trim($data['address'] ?? '');

$errors = [];

// --- VALIDACIONES ---
if ($first === '') $errors['firstName'] = 'Nombre es requerido.';
if ($last === '')  $errors['lastName']  = 'Apellido es requerido.';
if ($email === '') $errors['email']     = 'Email es requerido.';
if ($dni === '')   $errors['dni']       = 'DNI es requerido.';
if ($birth === '') $errors['dateOfBirth'] = 'Fecha de nacimiento es requerida.';
if ($password === '') $errors['password'] = 'Contraseña es requerida.';
if (!$hasLicense)  $errors['hasLicense'] = 'Debes confirmar que tienes licencia.';

if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email inválido.';
if ($dni && !preg_match('/^\d+$/', $dni)) $errors['dni'] = 'DNI debe contener solo números.';

if ($birth !== '') {
    $d = date_create_from_format('Y-m-d', $birth);
    if (!$d) $errors['dateOfBirth'] = 'Formato de fecha inválido (YYYY-MM-DD).';
    else {
        $today = new DateTime();
        $diff = $today->diff($d);
        if ($diff->y < 21) $errors['dateOfBirth'] = 'Debes tener al menos 21 años.';
    }
}

if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password)) {
    $errors['password'] = 'Contraseña insegura (mín. 8, 1 mayúscula, 1 número).';
}

if (!empty($errors)) fail($errors, 422);

// --- CHEQUEAR DUPLICADOS ---
$stmt = $conn->prepare("SELECT ID, Mail, DNI FROM clientes WHERE Mail = ? OR DNI = ?");
if (!$stmt) fail(['server' => 'Error preparando consulta: ' . $conn->error], 500);

$dni_int = (int)$dni; // convertir a int
$stmt->bind_param('si', $email, $dni_int);
$stmt->execute();
$res = $stmt->get_result();
if ($res && $row = $res->fetch_assoc()) {
    $conflicts = [];
    if (strcasecmp($row['Mail'], $email) === 0) $conflicts['email'] = 'El email ya está registrado.';
    if ((string)$row['DNI'] === (string)$dni_int) $conflicts['dni'] = 'El DNI ya está registrado.';
    if (!empty($conflicts)) fail($conflicts, 409);
}
$stmt->close();

// --- HASH CONTRASEÑA ---
$hash = password_hash($password, PASSWORD_DEFAULT);

// --- INSERT FINAL ---
$insert = $conn->prepare("
    INSERT INTO clientes 
    (Nombre, Apellido, DNI, Mail, Telefono, Nacimiento, Licencia, Contraseña, Direccion)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");
if (!$insert) fail(['server' => 'Error preparando INSERT: ' . $conn->error], 500);

$lic = $hasLicense; // tinyint(1)
if (!$insert->bind_param('ssisissss', $first, $last, $dni_int, $email, $phone, $birth, $lic, $hash, $address)) {
    fail(['server' => 'Error en bind_param: ' . $insert->error], 500);
}

if (!$insert->execute()) {
    fail(['server' => 'Error ejecutando INSERT: ' . $insert->error], 500);
}

$newId = $insert->insert_id;
$insert->close();

http_response_code(201);
echo json_encode(['success' => true, 'message' => 'Cuenta creada correctamente.', 'id' => $newId]);
exit;
