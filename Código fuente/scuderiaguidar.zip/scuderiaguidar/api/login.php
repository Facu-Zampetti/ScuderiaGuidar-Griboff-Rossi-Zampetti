<?php
// api/login.php
header('Content-Type: application/json; charset=utf-8');

// Incluir config central (ajusta la ruta si es necesario)
require_once __DIR__ . '/config.php'; // carga $conn

// Leer body JSON
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!$input || !isset($input['email']) || !isset($input['password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$email = trim($input['email']);
$password = $input['password'];

// Validaciones simples
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email inválido']);
    exit;
}

try {
    // Preparar consulta usando mysqli (prepared statement)
    $sql = "SELECT ID, Nombre, Mail, `Contraseña` FROM clientes WHERE Mail = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        // error preparando statement
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error de servidor (prepare)']);
        exit;
    }

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Credenciales inválidas']);
        exit;
    }

    file_put_contents(__DIR__ . '/debug_login.txt', print_r([
    'email' => $email,
    'password_recibido' => $password,
    'hash_bd' => $user['Contraseña'],
    'verify_result' => password_verify($password, $user['Contraseña'])
], true));

    // Verificar password contra el hash en BD (bcrypt)
    if (!password_verify($password, $user['Contraseña'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Credenciales inválidas']);
        exit;
    }

    // Inicio de sesión seguro
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    session_regenerate_id(true);

    $_SESSION['cliente_id'] = (int)$user['ID'];
    $_SESSION['cliente_nombre'] = $user['Nombre'];
    $_SESSION['cliente_mail'] = $user['Mail'];

    // Responder sin incluir la contraseña
    echo json_encode([
        'success' => true,
        'user' => [
            'id' => (int)$user['ID'],
            'nombre' => $user['Nombre'],
            'mail' => $user['Mail']
        ]
    ]);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error en servidor']);
    exit;
}
