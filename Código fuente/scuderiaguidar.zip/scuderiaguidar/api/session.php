<?php
// api/session.php
header('Content-Type: application/json; charset=utf-8');

// Incluimos config por consistencia (no obligatorio aquí)
// require_once __DIR__ . '/../config.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (isset($_SESSION['cliente_id'])) {
    echo json_encode([
        'logged' => true,
        'user' => [
            'id' => (int)$_SESSION['cliente_id'],
            'nombre' => $_SESSION['cliente_nombre'],
            'mail' => $_SESSION['cliente_mail']
        ]
    ]);
} else {
    echo json_encode(['logged' => false]);
}
