module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        primary: "#1A1A1A", // gray-900
        secondary: "#F7C52D", // yellow-400
        accent: "#FFD700", // yellow-300
        background: "#FFFFFF", // white
        surface: "#F8F9FA", // gray-50
        "text-primary": "#2D2D2D", // gray-800
        "text-secondary": "#6B7280", // gray-500
        success: "#10B981", // emerald-500
        warning: "#F59E0B", // amber-500
        error: "#EF4444", // red-500
        "border-default": "#E5E7EB", // gray-200
        "border-accent": "#F7C52D", // yellow-400
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
      },
      boxShadow: {
        subtle: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
        modal: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
      },
      transitionDuration: {
        '200': '200ms',
        '300': '300ms',
        '400': '400ms',
      },
      transitionTimingFunction: {
        'smooth': 'ease-in-out',
      },
      borderWidth: {
        '1': '1px',
        '2': '2px',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [],
}